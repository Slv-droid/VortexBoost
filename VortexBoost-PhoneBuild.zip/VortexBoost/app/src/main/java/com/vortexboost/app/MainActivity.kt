package com.vortexboost.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val bg = Color.rgb(16, 16, 26)
    private val purple = Color.rgb(139, 92, 246)
    private val white = Color.WHITE

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(24), dp(32), dp(24), dp(24))
            setBackgroundColor(bg)
        }

        val title = TextView(this).apply {
            text = "VORTEX BOOST"
            textSize = 28f
            setTextColor(white)
            gravity = Gravity.CENTER
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        root.addView(title, matchWrap())

        val subtitle = TextView(this).apply {
            text = "Oyun panelin hazır. FPS düşüşlerini takip etmene yardımcı olacak sade bir kayan panel."
            textSize = 15f
            setTextColor(Color.rgb(190, 190, 210))
            gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, dp(28))
        }
        root.addView(subtitle, matchWrap())

        val start = makeButton("KAYAN PANELİ AÇ") {
            if (Settings.canDrawOverlays(this)) {
                startService(Intent(this, OverlayService::class.java))
                Toast.makeText(this, "Vortex Boost paneli açıldı", Toast.LENGTH_SHORT).show()
            } else {
                val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                @Suppress("DEPRECATION")
                startActivityForResult(intent, 100)
            }
        }
        root.addView(start, matchWrap())

        val note = TextView(this).apply {
            text = "Bilgi: Bu ilk sürüm bir arayüz prototipidir. 60/90/120 seçimi hedef etiketi olarak görünür; oyunun FPS sınırını değiştirmez ve gerçek FPS ölçümü yapmaz."
            textSize = 13f
            setTextColor(Color.rgb(160, 160, 180))
            setPadding(0, dp(24), 0, 0)
        }
        root.addView(note, matchWrap())
        setContentView(root)
    }

    @Deprecated("Deprecated by Android, kept for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 100 && Settings.canDrawOverlays(this)) {
            startService(Intent(this, OverlayService::class.java))
        }
    }

    private fun makeButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        setTextColor(white)
        setBackgroundColor(purple)
        setOnClickListener { action() }
    }

    private fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}
