package com.vortexboost.app

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class OverlayService : Service() {
    private lateinit var windowManager: WindowManager
    private var panel: LinearLayout? = null
    private lateinit var params: WindowManager.LayoutParams
    private var collapsed = false
    private var selectedFps = 60

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (panel == null) showPanel()
        return START_NOT_STICKY
    }

    private fun showPanel() {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        params = WindowManager.LayoutParams(
            dp(250), WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(18)
            y = dp(120)
        }

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            setBackgroundColor(Color.rgb(24, 24, 40))
        }
        panel = card

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val title = TextView(this).apply {
            text = "VORTEX BOOST"
            textSize = 15f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        }
        header.addView(title, LinearLayout.LayoutParams(0, dp(38), 1f))
        val fold = Button(this).apply {
            text = "−"
            textSize = 18f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(70, 60, 105))
            setOnClickListener { toggleCollapsed() }
        }
        header.addView(fold, LinearLayout.LayoutParams(dp(42), dp(38)))
        card.addView(header)
        header.setOnTouchListener(DragTouchListener())

        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            tag = "body"
        }
        val target = TextView(this).apply {
            text = "FPS HEDEFİ  •  60"
            textSize = 16f
            setTextColor(Color.rgb(196, 181, 253))
            setPadding(0, dp(10), 0, dp(8))
            tag = "target"
        }
        body.addView(target)

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf(60, 90, 120).forEach { fps ->
            val b = Button(this).apply {
                text = fps.toString()
                textSize = 12f
                setTextColor(Color.WHITE)
                setBackgroundColor(if (fps == selectedFps) Color.rgb(124, 58, 237) else Color.rgb(55, 55, 75))
                setOnClickListener {
                    selectedFps = fps
                    target.text = "FPS HEDEFİ  •  $selectedFps"
                    for (i in 0 until row.childCount) {
                        val child = row.getChildAt(i) as Button
                        val value = child.text.toString().toIntOrNull()
                        child.setBackgroundColor(if (value == selectedFps) Color.rgb(124, 58, 237) else Color.rgb(55, 55, 75))
                    }
                    Toast.makeText(this@OverlayService, "$fps FPS hedef etiketi seçildi", Toast.LENGTH_SHORT).show()
                }
            }
            row.addView(b, LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginEnd = dp(4) })
        }
        body.addView(row)

        val status = TextView(this).apply {
            text = "GERÇEK FPS  •  ölçüm yok"
            textSize = 13f
            setTextColor(Color.rgb(190, 190, 205))
            setPadding(0, dp(10), 0, dp(4))
        }
        body.addView(status)
        val hint = TextView(this).apply {
            text = "Bu panel oyunun FPS ayarını değiştirmez."
            textSize = 11f
            setTextColor(Color.rgb(150, 150, 170))
        }
        body.addView(hint)
        card.addView(body)

        val close = Button(this).apply {
            text = "PANELİ KAPAT"
            textSize = 12f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(65, 45, 75))
            setOnClickListener { stopSelf() }
        }
        card.addView(close)

        windowManager.addView(card, params)
    }

    private fun toggleCollapsed() {
        val card = panel ?: return
        collapsed = !collapsed
        for (i in 0 until card.childCount) {
            val child = card.getChildAt(i)
            if (i > 0) child.visibility = if (collapsed) View.GONE else View.VISIBLE
        }
        val header = card.getChildAt(0) as? LinearLayout
        val fold = header?.getChildAt(1) as? Button
        fold?.text = if (collapsed) "+" else "−"
        params.width = dp(250)
        windowManager.updateViewLayout(card, params)
    }

    private inner class DragTouchListener : View.OnTouchListener {
        private var startX = 0
        private var startY = 0
        private var touchX = 0f
        private var touchY = 0f
        override fun onTouch(v: View, event: MotionEvent): Boolean {
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x
                    startY = params.y
                    touchX = event.rawX
                    touchY = event.rawY
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = startX + (event.rawX - touchX).toInt()
                    params.y = startY + (event.rawY - touchY).toInt()
                    panel?.let { windowManager.updateViewLayout(it, params) }
                    return true
                }
            }
            return false
        }
    }

    override fun onDestroy() {
        panel?.let {
            try { windowManager.removeView(it) } catch (_: Exception) { }
        }
        panel = null
        super.onDestroy()
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}
