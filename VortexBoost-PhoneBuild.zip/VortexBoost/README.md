# Vortex Boost (starter project)

This is a starter Android project for a draggable floating overlay and FPS target selector. It does **not** force a game to run at a chosen FPS and does not currently read real in-game FPS.

## Build without a computer (GitHub Actions)

1. Create/sign in to a GitHub account in your phone browser.
2. Create a new repository. A private repository is fine.
3. Upload the contents of this folder to the repository root (upload the files/folders inside `VortexBoost`, not the outer folder itself). Ensure `.github/workflows/build-apk.yml` is included. GitHub's mobile site may hide dot-folders; if so, use GitHub's desktop-site option in the browser or another upload method that preserves `.github`.
4. Open the repository's **Actions** tab and allow Actions if prompted.
5. Select **Build Vortex Boost APK**, tap **Run workflow**, and wait for the run to finish successfully.
6. Open the completed run and download the `VortexBoost-debug-apk` artifact. Extract the downloaded artifact ZIP to get `app-debug.apk`.
7. Only install APKs you built from source you trust. Android may ask permission to install from your browser/files app.

## Local build

Open this folder in Android Studio and build the `app` debug variant. A Gradle wrapper is not included in this starter project.
